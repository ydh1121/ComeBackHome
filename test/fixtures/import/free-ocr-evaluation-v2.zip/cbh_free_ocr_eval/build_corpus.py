from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
from hashlib import sha256
from datetime import date, timedelta
from io import BytesIO
import json, random

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'images'; OUT.mkdir(exist_ok=True)
FONT='/usr/share/fonts/truetype/nanum/NanumGothic.ttf'
variants=[('A_high_resolution','2026-10-12',1.0,False,False,False,False,False),('B_low_resolution','2026-10-12',0.65,False,False,False,False,False),('C_small_font','2026-10-12',1.0,True,False,False,False,False),('D_merged_headers','2026-10-12',1.0,False,False,False,False,False),('E_month_year_boundary','2026-12-28',1.0,False,False,False,False,False),('F_swapped_rows','2026-10-12',1.0,False,True,False,False,False),('G_decimal_clock','2026-10-12',1.0,False,False,True,False,False),('H_break_fractions','2026-10-12',1.0,False,False,False,True,False),('I_blank_cells','2026-10-12',1.0,False,False,False,False,False),('J_off_unreadable','2026-10-12',1.0,False,False,False,False,False),('K_similar_names','2026-10-12',1.0,False,False,False,False,False),('L_colors_notes_holidays','2026-10-12',1.0,False,False,False,False,True)]
base_names=['김하린','김하림','박서윤','이서연','정유진']
labels=['출근','퇴근','쉬는시간']; records=[]; manifest=[]

def row_truth(code,r,d,name):
    idx=(r*3+d*2)%7
    if code=='I_blank_cells' and (r+d)%4==0:
        return ('','','','BLANK')
    if code=='J_off_unreadable' and (r+d)%6==0:
        return ('휴무','','','OFF_CANDIDATE')
    if code=='J_off_unreadable' and (r+d)%6==1:
        return ('판독불가','?','?','UNREADABLE')
    a=['9','10.5','11','12','13.5','14','15'][idx]
    b=['18','19.5','20','21.5','22','23.5','23'][idx]
    rest=['0.5','1','1.5','2'][(r+d)%4]
    if code=='G_decimal_clock':
        a=['09.5','10.5','11.5','12.5','13.5','14.5','15.5'][idx]
        b=['17.5','18.5','19.5','20.5','21.5','22.5','23.5'][idx]
    if code=='H_break_fractions':rest=['0.5','1','1.5','2'][d%4]
    return (a,b,rest,'SHIFT')

def clock(v):
    if not v:return None
    try:
        z=float(v)
        if not (0<=z<24):return None
        whole=int(z);frac=z-whole
        if abs(frac)<1e-8:return f'{whole:02d}:00'
        if abs(frac-0.5)<1e-8:return f'{whole:02d}:30'
    except ValueError:pass
    return None

def fmtbreak(v):
    if not v:return None
    try:return int(float(v)*60)
    except ValueError:return None

for idx,(code,start,scale,small,swap,decimal,brk,color) in enumerate(variants):
    rng=random.Random(9257+idx)
    names=base_names[:(3+idx%3)]
    if code=='F_swapped_rows': names=list(reversed(names))
    if code=='K_similar_names':names=['김하린','김하림','김하림아','김하린아']
    base= date.fromisoformat(start)
    dates=[(base+timedelta(days=d)).isoformat() for d in range(7)]
    # Keep 22 columns: name + 7 groups x 3
    x0=18; namew=116; subw=101; hh=40; rh=43
    w=x0*2+namew+21*subw; h=130+len(names)*rh+52
    canvas=Image.new('RGB',(w,h),'white');draw=ImageDraw.Draw(canvas)
    titlefont=ImageFont.truetype(FONT,23); headerfont=ImageFont.truetype(FONT,14 if small else 18)
    datafont=ImageFont.truetype(FONT,13 if small else 18)
    draw.text((x0,8),'익명 합성 주간 7×3 근무표 — '+code,font=titlefont,fill='#1b263b')
    y0=49; dy=y0+hh
    draw.rectangle((x0,y0,x0+namew,dy+hh),fill='#e7eef8',outline='#8fa1ba',width=1)
    draw.text((x0+14,y0+29),'직원명',font=headerfont,fill='#263441')
    for d,iso in enumerate(dates):
        left=x0+namew+d*3*subw;right=left+3*subw
        draw.rectangle((left,y0,right,dy),fill='#eaf0fa',outline='#b4c2d6',width=1)
        draw.text((left+18,y0+10),iso+' ('+'월화수목금토일'[date.fromisoformat(iso).weekday()]+')',font=headerfont,fill='#172a43')
        for k,tag in enumerate(labels):
            x=left+k*subw
            draw.rectangle((x,dy,x+subw,dy+hh),fill='#e8edf4',outline='#aebac6',width=1)
            draw.text((x+9,dy+10),tag,font=headerfont,fill='#1a344d')
    cells=[]
    for r,name in enumerate(names):
        y=dy+hh+r*rh
        draw.rectangle((x0,y,x0+namew,y+rh),fill='#fffaf0' if color and r%2 else '#ffffff',outline='#b4c2d6',width=1)
        draw.text((x0+8,y+11),name,font=datafont,fill='#1e293b')
        for d,iso in enumerate(dates):
            a,b,c,status=row_truth(code,r,d,name)
            raws=[a,b,c]
            for k,text in enumerate(raws):
                left=x0+namew+(3*d+k)*subw
                fill='#fff5da' if color and d in (2,5) else ('#f3fff5' if color and d==0 else '#ffffff')
                draw.rectangle((left,y,left+subw,y+rh),fill=fill,outline='#b4c2d6',width=1)
                if text:
                    draw.text((left+11,y+12),text,font=datafont,fill='#203748')
            cells.append(dict(source_image_id=code,employee_row=r,employee_name=name,date=iso,weekday=date.fromisoformat(iso).weekday(),column_group=d,clock_in=clock(a) if status=='SHIFT' else None,clock_out=clock(b) if status=='SHIFT' else None,break_minutes=fmtbreak(c) if status=='SHIFT' else None,status=status,original_text={'clock_in':a,'clock_out':b,'break':c},review_required=True))
    if color:
        draw.text((x0,h-33),'주석: 공휴일 표시 / 예외사항은 근무 셀이 아닙니다',font=headerfont,fill='#a82334')
    if code=='D_merged_headers':draw.text((x0+600,h-30),'병합 날짜 머리글 테스트',font=headerfont,fill='#7c2d12')
    if scale!=1.0:
        canvas=canvas.resize((int(w*scale),int(h*scale)),Image.Resampling.BICUBIC)
        canvas=canvas.filter(ImageFilter.GaussianBlur(radius=.35))
    if code=='C_small_font':canvas=ImageEnhance.Contrast(canvas).enhance(.84)
    out=OUT/(code+'.png');canvas.save(out,optimize=True)
    data=out.read_bytes();records+=cells
    manifest.append(dict(id=code,path='images/'+out.name,sha256=sha256(data).hexdigest(),width=canvas.width,height=canvas.height,bytes=len(data),employee_rows=len(names),days=7,cells=len(cells),ground_truth='ground_truth.json',real_ocr_run=False))

(ROOT/'ground_truth.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'manifest.json').write_text(json.dumps({'schema':'cbh-ocr-free-candidate-fixtures-v1','provenance':'NEW synthetic PNG generation, not manually transcribed original images','images':manifest,'total_cells':len(records),'provider_runs':0,'production_writes':0},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'images':len(manifest),'ground_truth_cells':len(records),'bytes':sum(x['bytes'] for x in manifest)}))
