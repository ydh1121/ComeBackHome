"""Run a single account-scoped Cloudflare Workers AI probe from a trusted shell.

This file performs NO requests unless explicitly invoked. Requires the user to
have VERIFIED Workers Free + remaining quota on Cloudflare dashboard, then to
set required env values IN THE TRUSTED SHELL (never in ChatGPT or GitHub).
User has approved initial Meta License/AUP acceptance. Nothing is deployed.
Usage is NOT the same as token counts; authoritative Neurons delta must be
read from the account's actual Workers AI dashboard before/after the request.
"""
import argparse
import base64
import json
import os
from pathlib import Path
import sys
from time import perf_counter
import urllib.error
import urllib.request

MODEL='@cf/meta/llama-3.2-11b-vision-instruct'
ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser(description='Account-authenticated, Free-plan-only single OCR probe')
    group=ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--accept-meta',action='store_true',help='Use approved official prompt: agree')
    group.add_argument('--image',help='Local synthetic PNG basename or path')
    ap.add_argument('--day',type=int,choices=range(7),metavar='0..6',help='Compare one day crop with full width; requires Pillow')
    ap.add_argument('--max-tokens',type=int,default=1024)
    ap.add_argument('--out',help='Optional PRIVATE output JSON filepath for synthetic result')
    args=ap.parse_args()
    # Mandatory gates are explicitly confirmed through the actual account
    # dashboard. They are not automatically proven by environment variables.
    if os.getenv('CBH_CF_WORKERS_PLAN_VERIFIED') != 'FREE':
        ap.error('STOP: verify actual Workers Free plan in Cloudflare dashboard, then set CBH_CF_WORKERS_PLAN_VERIFIED=FREE')
    rem=os.getenv('CBH_CF_REMAINING_NEURONS_CONFIRMED','')
    if not rem.isdigit() or int(rem)<1000:
        ap.error('STOP: read current Workers AI Neurons remaining; require at least 1000 confirmed (safe buffer)')
    account=os.getenv('CLOUDFLARE_ACCOUNT_ID')
    token=os.getenv('CLOUDFLARE_AUTH_TOKEN')
    if not account or not token:
        ap.error('STOP: missing server-side CLOUDFLARE_ACCOUNT_ID/CLOUDFLARE_AUTH_TOKEN')
    if not (128 <= args.max_tokens <= 2048):
        ap.error('max-tokens must be within 128..2048 for this low-quota probe')
    if args.accept_meta:
        payload={'prompt':'agree'}
        image_id=None
    else:
        path=Path(args.image)
        if not path.is_file(): path=ROOT/'images'/args.image
        if not path.is_file() or path.suffix.lower()!='.png':
            ap.error('only local synthetic PNG files from this corpus are permitted')
        if path.resolve().parent != (ROOT/'images').resolve():
            ap.error('STOP: private/original images not allowed in this evaluation')
        data=path.read_bytes()
        image_id=path.stem
        if args.day is not None:
            try:
                from PIL import Image
                from io import BytesIO
                image=Image.open(BytesIO(data)).convert('RGB')
                factor=image.width / 2273
                x0=int(round(18*factor)); name_end=int(round(134*factor))
                start=int(round((134+303*args.day)*factor)); end=int(round((134+303*(args.day+1))*factor))
                name=image.crop((x0,0,name_end,image.height))
                date=image.crop((start,0,end,image.height))
                merged=Image.new('RGB',(name.width+date.width,image.height),'white')
                merged.paste(name,(0,0));merged.paste(date,(name.width,0))
                tmp=BytesIO(); merged.save(tmp,'PNG');data=tmp.getvalue()
            except ImportError:
                ap.error('Pillow needed only for --day crop; do not change original image')
        instructions=(ROOT/'OCR_PROMPT.txt').read_text(encoding='utf-8')
        if args.day is not None:
            instructions += '\n이 이미지는 원본 근무표의 직원명 열과 %d번째 날짜 그룹만 나란히 붙인 테스트입니다. 원본 column_group=%d를 유지하고 직원-날짜 관계는 이미지에 실제 있는 근거로만 추출하세요.'%(args.day+1,args.day)
        payload={ 'prompt':instructions, 'image':'data:image/png;base64,'+base64.b64encode(data).decode('ascii'),
                 'max_tokens':args.max_tokens,'temperature':0 }
    url=f'https://api.cloudflare.com/client/v4/accounts/{account}/ai/run/{MODEL}'
    request=urllib.request.Request(url,data=json.dumps(payload).encode('utf-8'),
        headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'},method='POST')
    started=perf_counter()
    try:
        with urllib.request.urlopen(request,timeout=60) as response:
            code=response.status
            body=response.read(1024*1024)
    except urllib.error.HTTPError as e:
        # Do not echo a server error body; headers/body can contain sensitive data.
        print(json.dumps({'status':'HTTP_FAILURE','http_code':e.code,'inference_executed':False}),file=sys.stderr)
        sys.exit(2)
    except (urllib.error.URLError,TimeoutError):
        print(json.dumps({'status':'NETWORK_FAILURE_OR_UNKNOWN','inference_executed':'UNKNOWN; DO NOT RETRY AUTOMATICALLY'}),file=sys.stderr)
        sys.exit(3)
    elapsed=round((perf_counter()-started)*1000)
    try: result=json.loads(body)
    except ValueError:
        print(json.dumps({'status':'NON_JSON_RESPONSE','http_code':code,'latency_ms':elapsed}),file=sys.stderr);sys.exit(2)
    success=result.get('success') is True and not result.get('errors')
    report={'model':MODEL,'status':'API_SUCCESS' if success else 'API_ERROR',
            'http_code':code,'latency_ms':elapsed,'scope':'Meta consent' if args.accept_meta else 'anonymous PNG',
            'image_id':image_id,'day':args.day,'neurons':'NOT_MEASURED: compare authoritative dashboard values',
            'token_usage':(result.get('result') or {}).get('usage') if isinstance(result.get('result'),dict) else None}
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if args.out and success:
        out=Path(args.out)
        if out.exists():ap.error('refuse to overwrite existing evidence')
        fd=os.open(out,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump({'run_metadata':report,'raw_api_result':result},f,ensure_ascii=False,indent=2)
    if not success:sys.exit(2)

if __name__=='__main__':main()
