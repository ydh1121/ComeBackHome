# ComeBackHome OCR free candidate benchmark — synthetic corpus

Status: **INPUTS PREPARED / REAL PROVIDER INFERENCE NOT RUN / NO PROVIDER SELECTED**.

- 12 newly generated anonymous Korean 7-day x 3-column schedule PNG fixtures. No real employee data.
- The JSON ground truth is generated from the synthetic image source data, *not* transcribed from real user screenshots.
- `manifest.json` contains SHA-256, size, dimensions, and row/cell counts. Image-ground-truth consistency is subject to human spot review.
- Read-only scorer: `python evaluate.py my_provider_cells.json`; baseline self-test `python evaluate.py --self-test` does **not** establish OCR model accuracy.
- For each run, record account Free plan confirmation, consent state, model id, image SHA, response usage/Neuron delta, elapsed time, whether output is JSON, and model error codes. No private keys, raw OCR responses, or original workplace screenshots in PR/CI/logs.
- Cloudflare `@cf/meta/llama-3.2-11b-vision-instruct` requires owner Meta license assent before first request. Never issue `prompt: agree` without owner approval.
- Confirm Workers AI Free plan and remaining quota via the Cloudflare dashboard before any model call. **Do not run on Workers Paid or with prepaid Gateway credits**; disable paid fallback. Even local `wrangler dev` inference may count against quota.
- Worker Pages Functions AI binding is supported, dashboard configured for Pages. This package **does not deploy or call the API**.
- Model output is evidence only. No direct D1 writes; integration must reuse existing person/structure/review/commit contract.
- Compare the same 12 image hashes with Google/OCR.space only if Cloudflare cannot pass real free-tier trial, or when explicitly doing controlled comparison.
- Existing nonimage PR92 / OCR PR91 / MAIN / deployed Pages unchanged by this package.
- The `status` field `OFF_CANDIDATE` is not an automatically-approved OFF value. A blank cell is not necessarily an OFF day.
- Metrics are cell-derived; a missing key remains missed, not implicitly correct. See scorer source. Actual latency and provider quota consumption are **NOT_MEASURED** until genuine calls occur.
