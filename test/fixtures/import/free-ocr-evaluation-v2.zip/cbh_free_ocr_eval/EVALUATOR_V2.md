# OCR scorer v2 — independent date/row/column metrics

The original 12 image files, `manifest.json`, and `ground_truth.json` are bit-identical to the v1 corpus. This release fixes `evaluate.py` without altering the original reference data.

## Bug fixed

The original scorer used `(source_image_id, employee_row, date, column_group)` as an exact lookup key and then scored whether the matched date was correct. An incorrect date never matched, so `date_matches` was tautologically perfect over matched cells. Worse, employee row or column errors likewise disappeared as unpaired cells.

v2 matches evidence within the same image by one-to-one maximum-weight assignment, using **multiple** independently imperfect anchors (row, column, employee name, date). The match does **not** use time/break/status for disambiguation. After matching, row, column, date, weekday, name, status, clock-in, clock-out, break and review-required are scored independently against all reference cells, with missing values counted wrong. Ambiguous/missing/extraneous predictions are explicitly reported. Do not interpret independent-field percentages as a proof of perfect record identity: matching can remain ambiguous if several anchors are wrong. Always inspect false-claim counters and per-status confusion.

`python evaluate.py --self-test` tests wrong dates, row/column swaps, names, time, break, OFF_CANDIDATE/BLANK/UNREADABLE confusion, missing/duplicated/out-of-source cells. It is **not** a real OCR benchmark. Use `python evaluate.py provider_predictions.json` to score actual model output conforming to `OCR_PROMPT.txt`.

## Strict cost/account boundary

`cloudflare_free_probe.py` is inert unless invoked in a trusted, network-enabled environment. It requires the Cloudflare dashboard to be checked **first**, and refuses to run unless `CBH_CF_WORKERS_PLAN_VERIFIED=FREE`, `CBH_CF_REMAINING_NEURONS_CONFIRMED` is a nonzero, recent dashboard reading (>=1000 buffer), and `CLOUDFLARE_ACCOUNT_ID`/`CLOUDFLARE_AUTH_TOKEN` exist in that trusted shell. Do not place tokens in chat, GitHub, public CI, logs, or files. Do not run on Workers Paid or via a paid AI Gateway. It makes at most one call per invocation, never retries on an uncertain network result, and deploys nothing.

The official one-time Meta consent command is `python cloudflare_free_probe.py --accept-meta`, now approved by the account owner but **not executed** in this package. After success and account quota recheck, run `python cloudflare_free_probe.py --image A_high_resolution.png --out private-result.json` in the same trusted environment. Use optional `--day 0` through `--day 6` to compare original full-image inference against a concatenated employee-name + date-column crop. This crop is not the original and must be reported separately; the combined row/day linkage must be checked. Neurons must be measured by dashboard before/after; missing API usage is `NOT_MEASURED`, not zero.

The current ChatGPT execution environment had neither authenticated Cloudflare account integration nor credentials; therefore no license request, model inference, Neurons consumption, or external model accuracy is claimed. Release/production/D1/PR91/PR92 all remain untouched.
