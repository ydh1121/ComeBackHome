"""Local, deterministic OCR cell scorer. No provider calls or persistence.

One-to-one cell pairing must NOT use date (nor row/column) as an exact lookup key;
that masks errors in the very attributes being measured. Pair by maximum-evidence
bipartite assignment within a source image, then grade each field independently.
Synthetic corpus/scorer self-tests are not evidence of a provider's accuracy.
"""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LABELS = ('SHIFT', 'OFF_CANDIDATE', 'BLANK', 'UNREADABLE')


def _hungarian_max(weights):
    """Pure stdlib maximum-weight 1:1 assignment for a square nonnegative matrix."""
    n = len(weights)
    if n == 0:
        return []
    m = max(max(row) for row in weights)
    u, v, p, way = [0] * (n+1), [0] * (n+1), [0] * (n+1), [0] * (n+1)
    for i in range(1, n+1):
        p[0] = i
        j0, minv, used = 0, [float('inf')] * (n+1), [False] * (n+1)
        while True:
            used[j0] = True
            i0, delta, j1 = p[j0], float('inf'), 0
            for j in range(1, n+1):
                if not used[j]:
                    cur = m - weights[i0-1][j-1] - u[i0] - v[j]
                    if cur < minv[j]:
                        minv[j], way[j] = cur, j0
                    if minv[j] < delta:
                        delta, j1 = minv[j], j
            for j in range(n+1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break
    result = [-1] * n
    for j in range(1, n+1):
        if p[j] != 0:
            result[p[j] - 1] = j-1
    return result


def _evidence(t, p):
    # Layout, person, and date are independent measured dimensions. Evidence
    # deliberately excludes clock, break, and status content to avoid silently
    # re-pairing a wrongly recognized time with a different ground-truth cell.
    row = t.get('employee_row') == p.get('employee_row')
    col = t.get('column_group') == p.get('column_group')
    person = t.get('employee_name') == p.get('employee_name')
    date = t.get('date') == p.get('date')
    if not ((row and col) or (person and col) or (person and date) or (row and date)):
        return 0
    return 10 * int(row) + 10 * int(col) + 10 * int(person) + 10 * int(date)


def _pair(truth, pred):
    """Match by source id; provide an unmatched prediction count and ambiguity flags."""
    by_truth, by_pred = defaultdict(list), defaultdict(list)
    for t in truth:
        by_truth[t.get('source_image_id')].append(t)
    for p in pred:
        by_pred[p.get('source_image_id')].append(p)
    pairs = []
    unmatched_preds = 0
    for image_id in set(by_truth) | set(by_pred):
        a, b = by_truth[image_id], by_pred[image_id]
        n, z = len(a), len(b)
        size = n + z
        matrix = [[0] * size for _ in range(size)]
        for i, t in enumerate(a):
            for j, item in enumerate(b):
                matrix[i][j] = _evidence(t, item)
        assignment = _hungarian_max(matrix)
        used = set()
        for i, t in enumerate(a):
            j = assignment[i]
            if j < z and matrix[i][j] > 0:
                pairs.append((t, b[j]))
                used.add(j)
            else:
                pairs.append((t, None))
        unmatched_preds += z - len(used)
    return pairs, unmatched_preds


def score(truth, pred):
    """All rates have explicit denominators; never count missing as correct."""
    if not isinstance(truth, list) or not isinstance(pred, list):
        raise ValueError('truth and predictions must be lists')
    if any(not isinstance(item, dict) for item in truth + pred):
        raise ValueError('each cell must be a JSON object')
    truth_key = [(x.get('source_image_id'),x.get('employee_row'),x.get('column_group')) for x in truth]
    if len(set(truth_key)) != len(truth_key):
        raise ValueError('ground truth contains ambiguous duplicate image/row/group positions')
    pred_key = [(x.get('source_image_id'),x.get('employee_row'),x.get('column_group')) for x in pred]
    duplicate_keys = len(pred_key) - len(set(pred_key))
    pairs, unmatched_predictions = _pair(truth, pred)
    counts = Counter()
    by_status = {name: Counter() for name in LABELS}
    confusion = {name: Counter() for name in LABELS}
    bad_cases = []
    for t, p in pairs:
        gt_status = t['status']
        if gt_status not in LABELS:
            raise ValueError(f'unknown truth status {gt_status}')
        subset = by_status[gt_status]
        subset['truth'] += 1
        if p is None:
            counts['missing_cells'] += 1
            subset['missing'] += 1
            confusion[gt_status]['MISSING'] += 1
            continue
        counts['aligned_cells'] += 1
        subset['aligned'] += 1
        fields = ('employee_row','column_group','date','weekday','employee_name','status')
        for field in fields:
            correct = p.get(field) == t.get(field)
            counts[field+'_matches'] += int(correct)
            subset[field+'_matches'] += int(correct)
        for field in ('clock_in','clock_out','break_minutes'):
            correct = p.get(field) == t.get(field)
            counts[field+'_matches_all'] += int(correct)
            subset[field+'_matches_all'] += int(correct)
            if gt_status == 'SHIFT':
                counts[field+'_shift_matches'] += int(correct)
        counts['row_and_column_matches'] += int(p.get('employee_row') == t['employee_row'] and p.get('column_group') == t['column_group'])
        review = p.get('review_required') is True
        counts['review_required_true'] += int(review)
        if not review:
            counts['dangerous_auto_confirmations'] += 1
            subset['dangerous_auto_confirmations'] += 1
        pred_status = p.get('status')
        confusion[gt_status][str(pred_status)] += 1
        if gt_status in ('BLANK','OFF_CANDIDATE','UNREADABLE') and pred_status == 'SHIFT':
            counts['dangerous_shift_on_nonshift'] += 1
            bad_cases.append({'source_image_id':t['source_image_id'],'employee_row':t['employee_row'],'column_group':t['column_group'],'truth':gt_status,'predicted':'SHIFT'})
        if gt_status in ('BLANK','UNREADABLE') and pred_status == 'OFF_CANDIDATE':
            counts['dangerous_off_on_blank_or_unreadable'] += 1
            bad_cases.append({'source_image_id':t['source_image_id'],'employee_row':t['employee_row'],'column_group':t['column_group'],'truth':gt_status,'predicted':'OFF_CANDIDATE'})
        if pred_status == 'UNREADABLE':
            counts['prediction_unreadable'] += 1
        if pred_status not in LABELS:
            counts['invalid_status'] += 1
        if pred_status == 'SHIFT' and (p.get('clock_in') is None or p.get('clock_out') is None):
            counts['incomplete_shift_predictions'] += 1
    shift_truth = sum(x['status']=='SHIFT' for x in truth)
    total = len(truth)
    def metric(matches, denominator):
        return {'correct':int(matches),'total':int(denominator),'accuracy':round(matches/denominator,6) if denominator else None}
    counts['unmatched_predictions'] = unmatched_predictions
    counts['duplicate_position_predictions'] = duplicate_keys
    counts['unknown_image_predictions'] = sum(x.get('source_image_id') not in {t['source_image_id'] for t in truth} for x in pred)
    bad_cases.extend([])
    return {
        'scorer_version':'2.0-independent-fields', 'real_provider_accuracy_measured':bool(pred),
        'truth_cells':total,'predicted_cells':len(pred),
        'aligned_cells':counts['aligned_cells'],'missing_cells':counts['missing_cells'],
        'unmatched_predictions':unmatched_predictions,'duplicate_position_predictions':duplicate_keys,
        'metrics':{
            'employee_row':metric(counts['employee_row_matches'],total),
            'column_group':metric(counts['column_group_matches'],total),
            'date':metric(counts['date_matches'],total),
            'weekday':metric(counts['weekday_matches'],total),
            'employee_name':metric(counts['employee_name_matches'],total),
            'row_and_column':metric(counts['row_and_column_matches'],total),
            'status':metric(counts['status_matches'],total),
            'clock_in_shift':metric(counts['clock_in_shift_matches'],shift_truth),
            'clock_out_shift':metric(counts['clock_out_shift_matches'],shift_truth),
            'break_minutes_shift':metric(counts['break_minutes_shift_matches'],shift_truth),
            'clock_in_all':metric(counts['clock_in_matches_all'],total),
            'clock_out_all':metric(counts['clock_out_matches_all'],total),
            'break_minutes_all':metric(counts['break_minutes_matches_all'],total),
            'review_required':metric(counts['review_required_true'],total),
        },
        'safety':{
            'dangerous_auto_confirmations':counts['dangerous_auto_confirmations'],
            'dangerous_shift_on_nonshift':counts['dangerous_shift_on_nonshift'],
            'dangerous_off_on_blank_or_unreadable':counts['dangerous_off_on_blank_or_unreadable'],
            'incomplete_shift_predictions':counts['incomplete_shift_predictions'],
            'invalid_status':counts['invalid_status'],
            'unreadable_predictions':counts['prediction_unreadable'],
        },
        'by_truth_status':{k:dict(v) for k,v in by_status.items()},
        'status_confusion':{k:dict(v) for k,v in confusion.items()},
        'dangerous_cases':bad_cases,
        'usage':{'model':'NOT_RECORDED_BY_SCORER','neurons':'NOT_MEASURED','latency_ms':'NOT_MEASURED'},
    }


def self_test(truth):
    exact = [dict(x) for x in truth]
    ref=score(truth,exact)
    assert ref['metrics']['date']['correct'] == len(truth)
    assert ref['metrics']['employee_row']['correct'] == len(truth)
    assert ref['metrics']['column_group']['correct'] == len(truth)
    assert ref['metrics']['clock_in_shift']['correct'] == sum(x['status']=='SHIFT' for x in truth)
    assert ref['safety']['dangerous_auto_confirmations'] == 0
    def mutate(i, changes):
        candidate = [dict(x) for x in truth]
        candidate[i].update(changes)
        return score(truth,candidate)
    # A wrong date must stay matched and be scored as WRONG, not silently missing.
    d=mutate(0, {'date':'2031-12-30'})
    assert d['missing_cells']==0 and d['metrics']['date']['correct']==len(truth)-1
    assert d['metrics']['column_group']['correct']==len(truth)
    row=mutate(0, {'employee_row':999})
    assert row['missing_cells']==0 and row['metrics']['employee_row']['correct']==len(truth)-1
    col=mutate(0, {'column_group':99})
    assert col['missing_cells']==0 and col['metrics']['column_group']['correct']==len(truth)-1
    name=mutate(0, {'employee_name':'잘못인식'})
    assert name['metrics']['employee_name']['correct']==len(truth)-1
    clk=mutate(0, {'clock_in':'09:30','clock_out':'18:30','break_minutes':999})
    assert clk['metrics']['clock_in_shift']['correct']==ref['metrics']['clock_in_shift']['correct']-1
    assert clk['metrics']['clock_out_shift']['correct']==ref['metrics']['clock_out_shift']['correct']-1
    assert clk['metrics']['break_minutes_shift']['correct']==ref['metrics']['break_minutes_shift']['correct']-1
    off=next(i for i,t in enumerate(truth) if t['status']=='OFF_CANDIDATE')
    blank=next(i for i,t in enumerate(truth) if t['status']=='BLANK')
    unread=next(i for i,t in enumerate(truth) if t['status']=='UNREADABLE')
    assert mutate(off, {'status':'SHIFT'})['safety']['dangerous_shift_on_nonshift']==1
    assert mutate(blank, {'status':'OFF_CANDIDATE'})['safety']['dangerous_off_on_blank_or_unreadable']==1
    assert mutate(unread, {'status':'SHIFT'})['safety']['dangerous_shift_on_nonshift']==1
    assert mutate(unread, {'review_required':False})['safety']['dangerous_auto_confirmations']==1
    missing=score(truth,exact[1:])
    assert missing['missing_cells']==1 and missing['metrics']['date']['correct']==len(truth)-1
    added=score(truth,exact+[dict(exact[0])])
    assert added['unmatched_predictions']==1 and added['duplicate_position_predictions']==1
    unknown=score(truth,exact+[dict(exact[0],source_image_id='UNKNOWN_SOURCE')])
    assert unknown['unmatched_predictions']==1
    return {'self_test':'PASS','real_provider_accuracy_measured':False,'cells':len(truth),
            'regressions_checked':['date-key bug','employee row','column group','employee name','clock-in','clock-out','break','OFF_CANDIDATE','BLANK','UNREADABLE','missing','duplicates','unknown source','approval']}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('prediction_json',nargs='?')
    ap.add_argument('--self-test',action='store_true')
    opts=ap.parse_args()
    truth=json.loads((ROOT/'ground_truth.json').read_text(encoding='utf-8'))
    if opts.self_test:
        print(json.dumps(self_test(truth),ensure_ascii=False,indent=2)); return
    if not opts.prediction_json:
        ap.error('pass provider predictions JSON; synthetic self-test is not provider accuracy')
    raw=json.loads(Path(opts.prediction_json).read_text(encoding='utf-8'))
    pred=raw.get('cells',[]) if isinstance(raw,dict) else raw
    print(json.dumps(score(truth,pred),ensure_ascii=False,indent=2))

if __name__=='__main__': main()
